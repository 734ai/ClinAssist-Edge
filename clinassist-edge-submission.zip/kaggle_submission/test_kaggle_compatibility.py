#!/usr/bin/env python3
"""
ClinAssist Edge - Comprehensive Kaggle Compatibility Test Suite
Tests all core components to ensure production readiness.
"""

import sys
import os
import time
import tempfile

# Add project to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def print_section(title):
    """Print a section header."""
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)

def print_test(test_name, passed, details=""):
    """Print test result."""
    status = "✓" if passed else "✗"
    print(f"{status} {test_name}")
    if details:
        print(f"  → {details}")

def test_dependencies():
    """Test all required dependencies."""
    print_section("TEST 1: DEPENDENCIES")
    
    dependencies = {
        'torch': 'PyTorch (tensors and neural networks)',
        'transformers': 'HuggingFace Transformers (model loading)',
        'huggingface_hub': 'HuggingFace Hub (authentication)',
        'peft': 'Parameter-Efficient Fine-Tuning',
        'bitsandbytes': 'Quantization support'
    }
    
    all_ok = True
    for module, description in dependencies.items():
        try:
            __import__(module)
            mod = sys.modules[module]
            version = getattr(mod, '__version__', 'unknown')
            print_test(f"{module:20} ({description})", True, f"v{version}")
        except ImportError as e:
            print_test(f"{module:20} ({description})", False, str(e))
            all_ok = False
    
    return all_ok

def test_module_imports():
    """Test all core module imports."""
    print_section("TEST 2: MODULE IMPORTS")
    
    modules = [
        ('model.load_model', 'load_model, get_device, MODEL_NAME'),
        ('model.quick_infer', 'infer, read_template'),
        ('model.safety_checks', 'perform_safety_check'),
        ('utils.logger', 'log_inference'),
    ]
    
    all_ok = True
    for mod_name, exports in modules:
        try:
            mod = __import__(mod_name, fromlist=exports.split(', '))
            for export in exports.split(', '):
                if not hasattr(mod, export.strip()):
                    raise AttributeError(f"Missing export: {export}")
            print_test(mod_name, True, exports)
        except Exception as e:
            print_test(mod_name, False, str(e))
            all_ok = False
    
    return all_ok

def test_file_structure():
    """Test required file structure."""
    print_section("TEST 3: FILE STRUCTURE")
    
    required_files = [
        ('model/load_model.py', 'Model loading module'),
        ('model/quick_infer.py', 'Inference pipeline'),
        ('model/safety_checks.py', 'Safety validation'),
        ('utils/logger.py', 'Audit logging'),
        ('prompts/templates.md', 'Clinical prompt templates'),
        ('notebooks/eval.ipynb', 'Evaluation notebook'),
        ('app/streamlit_app.py', 'Streamlit web UI'),
        ('demo/demo_interactive.py', 'Interactive demo'),
        ('requirements.txt', 'Dependencies list'),
        ('DEPLOYMENT.md', 'Deployment guide'),
    ]
    
    all_ok = True
    for file_path, description in required_files:
        full_path = os.path.join(os.path.dirname(__file__), file_path)
        exists = os.path.exists(full_path)
        print_test(f"{file_path:35} ({description})", exists)
        all_ok = all_ok and exists
    
    return all_ok

def test_device_detection():
    """Test device detection."""
    print_section("TEST 4: DEVICE DETECTION")
    
    try:
        from model.load_model import get_device
        device = get_device()
        print_test("Device detection", True, f"Selected: {device}")
        return True
    except Exception as e:
        print_test("Device detection", False, str(e))
        return False

def test_template_loading():
    """Test template loading."""
    print_section("TEST 5: TEMPLATE LOADING")
    
    try:
        from model.quick_infer import read_template
        
        templates = ['Differential Diagnosis', 'SOAP Note', 'Patient Instructions']
        all_ok = True
        
        for template_name in templates:
            try:
                template = read_template(template_name)
                print_test(f"Template: {template_name}", True, f"{len(template)} chars")
            except Exception as e:
                print_test(f"Template: {template_name}", False, str(e))
                all_ok = False
        
        return all_ok
    except Exception as e:
        print_test("Template loading", False, str(e))
        return False

def test_safety_checks():
    """Test safety check functionality."""
    print_section("TEST 6: SAFETY CHECKS")
    
    try:
        from model.safety_checks import perform_safety_check
        
        test_cases = [
            ("Rest and hydration recommended", False, "Safe advice"),
            ("Take aspirin 500mg daily", True, "Explicit dosage"),
            ("Patient has pneumonia", True, "Definitive diagnosis"),
            ("Consider possible causes", False, "Appropriate hedging"),
        ]
        
        all_ok = True
        for text, should_flag, description in test_cases:
            is_risky, warning = perform_safety_check(text)
            passed = is_risky == should_flag
            detail = f"{description} → Risk={is_risky}"
            print_test(f"Check: {text[:40]:40}", passed, detail)
            all_ok = all_ok and passed
        
        return all_ok
    except Exception as e:
        print_test("Safety checks", False, str(e))
        return False

def test_logging_system():
    """Test logging system."""
    print_section("TEST 7: LOGGING SYSTEM")
    
    try:
        from utils.logger import log_inference
        
        # Create a temporary log file for testing
        test_log_content = ""
        
        try:
            log_inference(
                input_prompt="Test prompt",
                generated_output="Test output",
                template_name="Test Template",
                model_name="test-model"
            )
            
            log_file = os.path.join(os.path.dirname(__file__), 'audit_log.txt')
            if os.path.exists(log_file):
                with open(log_file, 'r') as f:
                    content = f.read()
                
                entry_count = content.count('Timestamp:')
                size_kb = len(content) / 1024
                
                print_test("Logging to audit_log.txt", True, 
                          f"{entry_count} entries, {size_kb:.1f}KB")
                return True
            else:
                print_test("Logging to audit_log.txt", False, "Log file not created")
                return False
                
        except Exception as e:
            print_test("Logging to audit_log.txt", False, str(e))
            return False
            
    except Exception as e:
        print_test("Logger import", False, str(e))
        return False

def test_hf_authentication():
    """Test HuggingFace authentication setup."""
    print_section("TEST 8: HUGGINGFACE AUTHENTICATION")
    
    try:
        hf_key_file = os.path.join(os.path.dirname(__file__), 'huggingface-api-key')
        
        if os.path.exists(hf_key_file):
            try:
                with open(hf_key_file, 'r') as f:
                    key_content = f.read().strip()
                
                # Check if it looks like a valid token (starts with hf_)
                if key_content and len(key_content) > 10:
                    print_test("HuggingFace API key file", True, 
                              f"Key found, {len(key_content)} chars")
                    return True
                else:
                    print_test("HuggingFace API key file", False, "Empty or invalid key")
                    return False
            except Exception as e:
                print_test("HuggingFace API key file", False, str(e))
                return False
        else:
            print_test("HuggingFace API key file", True, 
                      "Not found (will use HF_TOKEN env var)")
            return True
            
    except Exception as e:
        print_test("HuggingFace authentication check", False, str(e))
        return False

def main():
    """Run all tests."""
    print("\n")
    print("╔" + "=" * 68 + "╗")
    print("║" + " " * 68 + "║")
    print("║" + "CLINASSIST EDGE - KAGGLE COMPATIBILITY TEST SUITE".center(68) + "║")
    print("║" + " " * 68 + "║")
    print("╚" + "=" * 68 + "╝")
    
    results = []
    
    # Run all tests
    results.append(("Dependencies", test_dependencies()))
    results.append(("Module Imports", test_module_imports()))
    results.append(("File Structure", test_file_structure()))
    results.append(("Device Detection", test_device_detection()))
    results.append(("Template Loading", test_template_loading()))
    results.append(("Safety Checks", test_safety_checks()))
    results.append(("Logging System", test_logging_system()))
    results.append(("HF Authentication", test_hf_authentication()))
    
    # Summary
    print_section("TEST SUMMARY")
    
    total_tests = len(results)
    passed_tests = sum(1 for _, result in results if result)
    
    for test_name, result in results:
        status = "✓" if result else "✗"
        print(f"{status} {test_name}")
    
    print("\n" + "-" * 70)
    print(f"Results: {passed_tests}/{total_tests} test groups passed")
    
    if passed_tests == total_tests:
        print("\n" + "🎉 " * 10)
        print("✓ PROJECT IS FULLY READY FOR KAGGLE")
        print("🎉 " * 10)
        print("\nNext steps:")
        print("1. Record video demo: python demo/demo_interactive.py")
        print("2. Run notebook: jupyter notebook notebooks/eval.ipynb")
        print("3. Test web UI: streamlit run app/streamlit_app.py")
        print("4. Submit to competition!")
        return 0
    else:
        print("\n⚠ Some tests failed. Review errors above.")
        return 1

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
