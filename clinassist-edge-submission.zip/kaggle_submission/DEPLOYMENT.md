# ClinAssist Edge - Deployment Guide

## Table of Contents
1. [Prerequisites & System Requirements](#prerequisites--system-requirements)
2. [Installation](#installation)
3. [Running the Application](#running-the-application)
4. [Configuration for Different Environments](#configuration-for-different-environments)
5. [Optimization for Low-Resource Devices](#optimization-for-low-resource-devices)
6. [Troubleshooting](#troubleshooting)
7. [Regulatory & Compliance Considerations](#regulatory--compliance-considerations)

---

## Prerequisites & System Requirements

### Minimum Hardware Requirements

| Environment | RAM | Storage | CPU | GPU | Network |
|-------------|-----|---------|-----|-----|---------|
| **Desktop/Laptop (Development)** | 8 GB | 15 GB | 4-core | Optional (recommended) | Optional (offline-capable) |
| **Low-Resource Clinic** | 4 GB | 10 GB | 2-core | None | Optional (offline-capable) |
| **Edge Device (ARM)** | 2 GB | 8 GB | ARM 64-bit | None | Optional |
| **High-Performance Server** | 16+ GB | 20 GB | 8+ core | Recommended | Optional |

### Software Requirements

- **Python 3.9+** (3.11+ recommended)
- **pip** (Python package manager)
- **Git** (for cloning repository)
- **CUDA 11.8+** (optional, for NVIDIA GPU acceleration)
- **cuDNN** (optional, with CUDA)

### Supported Operating Systems
- ✅ Linux (Ubuntu 20.04+, Debian 11+, CentOS 8+)
- ✅ macOS (10.14+, including Apple Silicon M1/M2)
- ✅ Windows 10/11 (with WSL2 recommended)

---

## Installation

### Step 1: Clone the Repository

```bash
git clone https://github.com/your-username/clinassist-edge.git
cd clinassist-edge
```

### Step 2: Create a Python Virtual Environment

#### On Linux/macOS:
```bash
python3 -m venv venv
source venv/bin/activate
```

#### On Windows (PowerShell):
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

#### On Windows (CMD):
```cmd
python -m venv venv
venv\Scripts\activate.bat
```

### Step 3: Install Dependencies

```bash
# Upgrade pip
pip install --upgrade pip

# Install base requirements
pip install -r requirements.txt

# (Optional) For GPU support (NVIDIA)
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118

# (Optional) For 4-bit quantization on resource-constrained devices
pip install bitsandbytes

# (Optional) For LoRA fine-tuning
pip install -r requirements-lora.txt
```

### Step 4: Download the Model

#### Option A: Using Hugging Face Hub (Default)

```bash
# Test model loading (downloads on first run)
python model/load_model.py
```

This will download the model (~2-4 GB for MedGemma-2B) on first use. Subsequent runs will use the cached version.

#### Option B: Pre-download Model

```bash
# Using Hugging Face CLI
huggingface-cli download google/medgemma-2b --local-dir ./models/medgemma-2b

# Then update model/load_model.py to point to local directory:
# MODEL_NAME = "./models/medgemma-2b"
```

#### Option C: For Offline Deployment

1. Download model on a machine with internet
2. Copy the `~/.cache/huggingface/hub/models--google--medgemma-2b` directory to target device
3. Set environment variable: `export HF_HOME=/path/to/huggingface/hub`

---

## Running the Application

### Standard Deployment (Desktop/Laptop)

```bash
# Activate virtual environment
source venv/bin/activate  # Linux/macOS
# or
venv\Scripts\activate  # Windows

# Run Streamlit app
streamlit run app/streamlit_app.py
```

The app will be available at `http://localhost:8501`

### Headless Deployment (Server/Remote)

```bash
# Run with remote server configuration
streamlit run app/streamlit_app.py \
  --server.headless true \
  --server.port 8501 \
  --server.address 0.0.0.0
```

Then access from remote machine: `http://<server-ip>:8501`

### Quick Inference Testing

```bash
# Test the inference pipeline directly
python model/quick_infer.py

# Or within Python:
from model.load_model import load_model
from model.quick_infer import infer

tokenizer, model = load_model()
input_data = {'patient_symptoms': '45-year-old male, fever 38.9C, productive cough'}
prompt, output, model_name = infer(model, tokenizer, 'Differential Diagnosis', input_data)
print(output)
```

### Evaluation

```bash
# Run evaluation notebook
jupyter notebook notebooks/eval.ipynb

# Or from command line:
jupyter nbconvert --to notebook --execute notebooks/eval.ipynb
```

---

## Configuration for Different Environments

### Docker Deployment

Create a `Dockerfile`:

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

# Pre-download model to avoid delays on first run
RUN python model/load_model.py

EXPOSE 8501

CMD ["streamlit", "run", "app/streamlit_app.py", \
     "--server.headless", "true", \
     "--server.port", "8501"]
```

Build and run:

```bash
docker build -t clinassist-edge .
docker run -p 8501:8501 clinassist-edge
```

### Cloud Deployment (AWS, GCP, Azure)

#### AWS EC2
```bash
# Launch EC2 instance (t3.large recommended minimum)
# SSH into instance
ssh -i your-key.pem ec2-user@your-instance-ip

# Install dependencies
sudo yum update -y
sudo yum install python3 python3-pip git -y

# Follow standard installation steps above
```

#### Google Cloud Run
```bash
# Create app.yaml
echo "runtime: python311" > app.yaml

# Deploy
gcloud run deploy clinassist-edge --source .
```

### Mobile/Edge Device (ARM-based)

See [Optimization for Low-Resource Devices](#optimization-for-low-resource-devices) section below.

---

## Optimization for Low-Resource Devices

### 1. Model Quantization (4-bit)

Update `model/load_model.py` to enable quantization:

```python
tokenizer, model = load_model(quantize=True)
```

Benefits:
- Reduces model size from 4GB → 1GB
- Slightly slower inference (2-5 seconds vs <1 second on GPU)
- Compatible with 2GB+ RAM devices

### 2. Inference Settings Optimization

Adjust in `app/streamlit_app.py`:

```python
# Reduce max_new_tokens for faster responses
max_new_tokens=200  # Reduced from 500
```

### 3. CPU-Only Optimization

```bash
# Install CPU-optimized PyTorch
pip install torch --index-url https://download.pytorch.org/whl/cpu
```

### 4. Memory-Efficient Model Loading

```python
# In load_model.py
model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    device_map="cpu",  # Use CPU with manual memory management
    torch_dtype=torch.float32  # Use float32 for CPU stability
)
```

### 5. Progressive Model Loading (Experimental)

For ultra-low-resource devices, consider loading only parts of the model into memory at a time. This requires custom implementation but is possible with Hugging Face's `device_map` features.

---

## Troubleshooting

### Model Loading Issues

**Problem**: `OSError: Can't load model. Model not found`

**Solution**:
```bash
# Clear cache and re-download
rm -rf ~/.cache/huggingface/hub/
python model/load_model.py
```

**Problem**: `OutOfMemoryError` when loading model

**Solution**:
- Enable quantization: `load_model(quantize=True)`
- Reduce `max_new_tokens` in inference
- Close other applications to free memory
- Use a device with more RAM

### Streamlit Issues

**Problem**: `Port 8501 already in use`

**Solution**:
```bash
streamlit run app/streamlit_app.py --server.port 8502
```

**Problem**: `Module not found` errors

**Solution**:
```bash
# Ensure you're in the project root directory
cd clinassist-edge

# Verify Python path
python -c "import sys; print(sys.path)"

# Reinstall in development mode
pip install -e .
```

### GPU Not Detected

**Problem**: Model loads on CPU instead of GPU

**Solution**:
```bash
# Verify CUDA installation
python -c "import torch; print(torch.cuda.is_available())"
python -c "import torch; print(torch.cuda.get_device_name(0))"

# Reinstall PyTorch with CUDA support
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
```

### Inference Slowness

**Problem**: Inference takes >10 seconds

**Diagnosis**:
- Check if GPU is being used: `torch.cuda.is_available()` and `torch.cuda.current_device()`
- Monitor CPU/RAM usage: `htop` (Linux) or Task Manager (Windows)

**Solutions**:
- Enable GPU if available
- Enable quantization: `load_model(quantize=True)`
- Reduce `max_new_tokens`
- Use a faster device (GPU > Apple Silicon > CPU)

### Audit Log Issues

**Problem**: `Permission denied` when writing to `audit_log.txt`

**Solution**:
```bash
# Fix file permissions
chmod 666 audit_log.txt

# Or ensure write permission to directory
chmod 755 .
```

---

## Regulatory & Compliance Considerations

### GDPR Compliance (European Union)

- ✅ **Data Processing Agreement**: All patient data processed locally; no transfer to external servers
- ✅ **Consent**: Ensure explicit patient consent before use
- ✅ **Data Retention**: Implement data deletion protocols; document in local policies
- ✅ **Audit Trails**: Maintained in `audit_log.txt` for accountability

**Required Actions**:
1. Implement encrypted disk storage for audit logs
2. Define data retention policy (e.g., delete logs after 90 days)
3. Document security measures in Data Protection Impact Assessment (DPIA)

### HIPAA Compliance (United States)

- ✅ **Business Associate Agreement**: Not required (no external data transfer)
- ⚠️ **Access Controls**: Restrict access to authorized users only
- ⚠️ **Audit Controls**: Maintain audit logs of all inferences
- ⚠️ **Transmission Security**: Use HTTPS for remote deployments

**Required Actions**:
1. Use HTTPS/TLS for any network communication
2. Implement user authentication (username/password or SSO)
3. Enable encryption at rest (OS-level disk encryption)
4. Regular security audits and penetration testing

### Other Regional Requirements

| Region | Key Requirements | Implementation |
|--------|-----------------|----------------|
| **India (DPDP Act)** | Data localization; consent | All data local; explicit consent workflow |
| **Brazil (LGPD)** | Data protection impact assessment | Document security measures in LGPD checklist |
| **China** | Data sovereignty | Deploy locally with no external data transfer |

### Security Best Practices

1. **Firewall Configuration**:
   ```bash
   # Only allow local access (default)
   streamlit run app/streamlit_app.py --server.address 127.0.0.1
   
   # For multi-user clinic with trusted network
   streamlit run app/streamlit_app.py --server.address 192.168.1.0  # Adjust as needed
   ```

2. **Disk Encryption**:
   ```bash
   # Linux: Use LUKS
   sudo cryptsetup luksFormat /dev/sdX
   
   # macOS: Use FileVault
   # Settings > Security & Privacy > FileVault > Turn On
   
   # Windows: Use BitLocker
   # Settings > System > About > Device encryption
   ```

3. **Regular Updates**:
   ```bash
   # Keep dependencies up to date
   pip install --upgrade -r requirements.txt
   ```

4. **Audit Log Rotation**:
   ```bash
   # Archive and compress old logs (e.g., weekly)
   gzip audit_log.txt
   mv audit_log.txt.gz archive/audit_log_$(date +%Y%m%d).txt.gz
   ```

---

## Support & Additional Resources

- **GitHub Issues**: [Link to project issues]
- **Documentation**: See `README.md` and code docstrings
- **Evaluation Results**: See `notebooks/eval.ipynb`
- **Audit Logs**: Check `audit_log.txt` for inference history

---

**Last Updated**: 2026-01-23  
**Status**: Production-Ready
